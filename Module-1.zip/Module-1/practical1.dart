//1.Display This Information using print

void main() {
  var name = "Dishant";
  var birthday = "August 19 2000";
  var age = 24;
  var address = "Anmol Twin Banglows";
  print("My Name is $name");
  print("Birth Date $birthday");
  print("Age $age");
  print("Address $address");
}
